
package esercizio1_andoniu;
import java.util.*;

public class Calcolatrice {
    
    public int somma(int a,int b){
        return a+b;
                                  }
    public int differenza(int a,int b){
        return a-b;
                                  }
    public int moltiplicazione(int a,int b){
        return a*b;
                                  }
    public int divisione(int a,int b){
        return a/b;
                                  }
        public double veradiv(int a,int b){
        return (double)a/b;
                                  }
    public int potenza(int a,int b){
        int c,copia=a;
            for(c=1;c<b;c++)
              a*=copia;
         return a;
                                  }
    
}
