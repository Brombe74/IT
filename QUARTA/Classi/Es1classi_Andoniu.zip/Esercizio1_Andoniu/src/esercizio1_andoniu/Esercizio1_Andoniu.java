
package esercizio1_andoniu;
import java.util.*;

public class Esercizio1_Andoniu {

   
    public static void main(String[] args) {
    Scanner input= new Scanner(System.in);
    int num1,num2;
     Calcolatrice c= new Calcolatrice();
     System.out.println("Inserisci il primo numero");
     num1=input.nextInt();
     System.out.println("Inserisci il secondo numero");
     num2=input.nextInt();
     
     System.out.println("--SOMMA DEI NUMERI--");
     int somm=c.somma(num1, num2);
     System.out.println(somm);
     
     System.out.println("--DIFFERENZA DEI NUMERI--");
     int diff=c.differenza(num1,num2);
     System.out.println(diff);
     
     System.out.println("--MOLTIPLICAZIONE DEI NUMERI--");
     int molt=c.moltiplicazione(num1,num2);
     System.out.println(molt);
     
     System.out.println("--DIVISIONE DEI NUMERI(TRA INTERI)--");
     int div=c.divisione(num1,num2);
     System.out.println(div);
     
      System.out.println("--DIVISIONE DEI NUMERI--");
     double divera=c.veradiv(num1,num2);
     System.out.println(divera);
     
     System.out.println("--POTENZA DEL PRIMO NUMERO ALLA SECONDO NUMERO--");
     int pot=c.potenza(num1,num2);
     System.out.println(pot);
     
    }
    
}
