
package persona;
import java.util.*;


public class Persona {

    
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        persona p1=new persona();
        String Nome,Cognome,Indirizzo;
        int età=0,scelta=8,N_scarpe=30; //inizializzazione delle variabili per entrare nei cicli
        int etàprov,N_scarpeprov;
        double altezza=1.39;
        double altezza_prov;
        
        System.out.println("*-Inserisci il tuo nome-*");    //varie richieste
        Nome=input.nextLine();
        p1.SetNome(Nome);
        
        System.out.println("*-Inserisci il tuo cognome-*");
        Cognome=input.nextLine();
        p1.SetCognome(Cognome);
        
        System.out.println("*-Inserisci il tuo indirizzo di casa-*");
        Indirizzo=input.nextLine();
        p1.SetIndirizzo(Indirizzo);
        
        do{  
            System.out.println("*-Inserisci la tua eta-*");
            età=input.nextInt();
           }while(età<10 || età>100);
        p1.Seteta(età);
     
        do{  
            System.out.println("*-Inserisci il tuo numero di scarpe-*");
            N_scarpe=input.nextInt();
           }while(N_scarpe<31 || N_scarpe>48);
        p1.Setn_scarpe(N_scarpe);
        
        do
        {
            System.out.println("*-Inserisci la tua altezza (in metri)-*");
            altezza=input.nextDouble();
        }while(altezza<1.40 || altezza>2.1);
        p1.Set_altezza(altezza);
    
    
       System.out.println("\n***Dati di"+p1.GetCognome()+" "+p1.GetNome()+"***\n"); //stampa dei dati
       System.out.println("Nome: "+p1.GetNome()+"\nCognome:"+p1.GetCognome()+"\neta':"+p1.GetEta());   //4 stampe in quanto fare una
       System.out.println("Indirizzo di casa: "+p1.GetIndirizzo()+"\nEta': "+p1.GetEta()+"\nNumero di Scarpe: "+p1.Getn_scarpe());//risultava occupare troppo spazio
       System.out.println("Altezza: "+p1.GetAltezza());
       
       do{
        System.out.println("\nVuoi cambiare Indirizzo, eta' , altezza o numero di scarpe??");   //richiesta del possibile cambiamento
        System.out.println("[0] per non cambiare nulla \n[1] per cambiare l'indirizzo \n[2] per cambiare l'eta' \n[3] per cambiare l'altezza");
        System.out.println("[4] per cambiare numero di scarpe\n[5] per cambiare tutto");
        scelta=input.nextInt();
        
       switch (scelta)
        {
            case 0:
                break;
                
            case 1:
                System.out.println("Inserisci il nuovo indirizzo:");
                Indirizzo=input.nextLine();
                p1.SetIndirizzo(Indirizzo);
                break;
                
            case 2:
                System.out.println("Inserisci la nuova eta':");
                etàprov=input.nextInt();
                if(etàprov<età)
                    {
                        System.out.println("Non è possibile ringiovanire!");
                        break;
                    }
                else
                    p1.Seteta(etàprov);
                break;
            case 3:
                System.out.println("Inserisci la nuova altezza:");
                altezza_prov=input.nextDouble();
                if(altezza_prov<altezza)
                    {
                        System.out.println("Non è possibile rimpicciolirsi!");
                        break;
                    }
                else
                p1.Set_altezza(altezza_prov);
                
                break;
            case 4:
                System.out.println("Inserisci il nuovo numero di scarpe:");
                N_scarpeprov=input.nextInt();
                if(N_scarpeprov<N_scarpe)
                {
                    System.out.println("Non è possibile rimpicciolirsi!");
                    break;
                }
                else
                p1.Setn_scarpe(N_scarpeprov);
                break;
            case 5:
                
                System.out.println("Inserisci il nuovo indirizzo:");
                Indirizzo=input.nextLine();
                p1.SetIndirizzo(Indirizzo);
                
                
                System.out.println("Inserisci la nuova eta':");
                etàprov=input.nextInt();
                if(etàprov<età)
                    {
                        System.out.println("Non è possibile ringiovanire!");
                        break;
                    }
                else
                    p1.Seteta(etàprov);
                
                System.out.println("Inserisci la nuova altezza:");
                altezza_prov=input.nextDouble();
                if(altezza_prov<altezza)
                    {
                        System.out.println("Non è possibile rimpicciolirsi!");
                        break;
                    }
                else
                p1.Set_altezza(altezza_prov);
                
                System.out.println("Inserisci il nuovo numero di scarpe:");
                N_scarpeprov=input.nextInt();
                if(N_scarpeprov<N_scarpe)
                {
                    System.out.println("Non è possibile rimpicciolirsi!");
                    break;
                }
                else
                p1.Setn_scarpe(N_scarpeprov);
                break;
                
            default:
                System.out.println("Scelta non disponibile");
        }
        
               System.out.println("\n***Dati di"+p1.GetCognome()+" "+p1.GetNome()+"***\n"); //stampa 
               System.out.println("Nome: "+p1.GetNome()+"\nCognome:"+p1.GetCognome());   //4 stampe in quanto fare una
               System.out.println("Indirizzo di casa: "+p1.GetIndirizzo()+"\nEta': "+p1.GetEta()+"\nNumero di Scarpe: "+p1.Getn_scarpe());//risultava occupare troppo spazio
               System.out.println("Altezza: "+p1.GetAltezza());
             
       }while(scelta!=0);
      
      
    }
}
