
package persona;

public class persona 
{
        private String Nome;
        private String Cognome;
        private String Indirizzo;
        
        private int eta;
        private int n_scarpe;
        
        private double altezza;
        
    public persona()
    {
        
    }
    
     public persona(String nome,String cognome,String Indirizzo,String eta, String n_scarpe)
    {
        this.Nome=nome;
        this.Cognome=cognome;
        this.Indirizzo=Indirizzo;
        this.eta=Integer.parseInt(eta);
        this.n_scarpe=Integer.parseInt(n_scarpe);
    }
    
    public void SetNome(String nome)
    {
        this.Nome=nome;
    }
    
    public void SetCognome(String cognome)
    {
        this.Cognome=cognome;
    }
   
    public void SetIndirizzo(String indirizzo)
    {
        this.Indirizzo=indirizzo;
    }
    
    public void Seteta(int eta)
    {
        this.eta=eta;
    }        
    
    public void Setn_scarpe(int nscarpe)
    {
        this.n_scarpe=nscarpe;
    }
    
    public void Set_altezza(double altezza)
    {
        this.altezza=altezza;
    }
    
    public String GetNome()
    {
        return this.Nome;
    }
    
    public String GetCognome()
    {
        return this.Cognome;
    }
    
    public String GetIndirizzo()
    {
        return this.Indirizzo;
    }
    
    public int GetEta()
    {
        return this.eta;
    }
    
    public int Getn_scarpe()
    {
        return this.n_scarpe;
    }
    
    public double GetAltezza()
    {
        return this.altezza;
    }
    
    public String TrasformaInt(int numero)
    {
        String Stringa="";
        Stringa=Stringa+numero;
        
        return Stringa;
        
    }
    
    public String TrasformaDoub(double numero)
    {
        String Stringa="";
        Stringa=Stringa+numero;
        
        return Stringa;
        
    }
}
