
package vettore;
import java.util.*;

public class Vettore {
    
    public static boolean ControlloVettore(int V[],int granvett,int i)
    {
        if(i>granvett)
            return true;
        else if(V[i]>10)
            return ControlloVettore(V,granvett,i+1);
        else
            return false;
            
    }

 
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        int granvett,num,i;
        boolean controllo;
        
        System.out.println("Inserisci la grandezza del vettore");
        granvett=input.nextInt();
        
        int V[]=new int[granvett];
        
        for(i=0;i<V.length;i++)
        {
            do
            {
             System.out.println("Inserisci il numero in posizione "+i+": ");
             num=input.nextInt();
            }while(num<0);
            
        }
        i=0;
        controllo=ControlloVettore(V,granvett,i);
        
        if(controllo==true)
            System.out.println("Tutti gli elementi del vettore sono maggiori di 10");
        else 
            System.out.println("Non tutti gli elementi del vettore sono maggiori di 10");
        }
        
        
        
        
       
        
    }
    
