
import java.util.*;

public class Ricerca_Binaria {
	public static int[] popolavettore(int V[])
	{   Scanner input= new Scanner(System.in);
		int i;
		for(i=0;i<V.length;i++)
			{V[i]=input.nextInt();
			}
		return V;
	}
public static int[] ordinavettore(int v[])
	{int i,j,scambio;
		for(i=0;i<v.length;i++)
			{for(j=i+1;j<v.length;j++)
				{if(v[i]>v[j])
					{scambio=v[i];
					 v[i]=v[j];
					 v[j]=scambio;
					}
				}
			}
		return v;	
	}
   public static int ricercabinaria(int v[],int num,int inizio,int fine)
   {	Scanner input= new Scanner(System.in);
       int meta=(inizio+fine)/2;
       if(num=meta);
		return num;
		else if(num<meta)
			{inizio=0;
			 fine=meta;
			 return ricercabinaria(v[],num,inizio,fine);
			}
		else if(num>meta)
			{inizio=meta;
			fine=v.length;
			return ricercabinaria(v[],num.inizio,fine);
			}
		return num;
   }
   
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int i,c,num,fond,fin;
        System.out.println("Inserisci la grandezza del vettore");
        i=input.nextInt();
        int V[]= new int[i];
        System.out.println("Inserisci i valori del vettore");
        V=popolavettore(V);
        V=ordinavettore(V);
        System.out.println("--VETTORE--");
        for(c=0;c<V.length;c++)
			{System.out.print(""+V[c]);
			}
		fond=0;
        fin=V.length;
        System.out.println("\nInserisci numero che vuoi cercare:");
        num=input.nextInt();
        num=ricercabinaria(V,num,fond,fin);
        System.out.println("La posizione del tuo numero:"+num);
    }
    
}
