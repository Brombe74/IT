
package esclassi;
import java.util.*;

public class EsClassi {
    //posso scrivere altre classi
    
    public static class Miaclasse{
        
        private String messaggio; //variabile di classe
        
     /*   public Miaclasse(){         costruttore
            messaggio="Bene";
           
            
                          }*/
        public Miaclasse(String I,String C)// secondo costruttore con parametri
        {
            messaggio="Ciao come stai "+I +" "+C+"?";
        }
        public String Stampa(){
           return messaggio;
           
                              }
         
                                 } //fine mia classe
    
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in); 
        String Nome;
        String Cognome;
        System.out.println("Inserisci nome");
        Nome=input.nextLine();
        System.out.println("Inserisci cognome");
        Cognome=input.nextLine();
        Miaclasse variabile1= new Miaclasse(Nome,Cognome);
        
        System.out.println(variabile1.Stampa());
                                            } //fine main
    
}// fine class principale quella dove c'è il main