
package verifica_andoniu_es1;
import java.util.*;

public class Verifica_Andoniu_es1 {

    public static int Binario(int ndec)
    {
        if (ndec==0)
            return 0;
        else 
        {
           
            System.out.println(ndec%2);
            return Binario(ndec/2);
        }
            
    }
    
    public static void main(String[] args) 
    {   
        Scanner input =new Scanner(System.in);
        int numerodec,numerobin,j;    
        int ausbin[]=new int[100];     //variabile ausiliaria che nel metodo serve per
                                        //allocare il resto della divisione
                                                              
        System.out.println("Inserisci Il numero:");
        numerodec=input.nextInt();
        if(numerodec<0)
            System.out.println("Conversione non disponibile in questo esercizio");
        else if(numerodec<2 && numerodec>=0)
        {       
            System.out.println(""+numerodec+" in binario: "+numerodec);
        }
        else
        {  
        
        System.out.println(""+numerodec+" in binario:\n ");     
        numerobin=Binario(numerodec);
        System.out.println("\n(bisogna leggere il numero dal basso verso l'alto,mi dispiace per questo inconveniente)");
        }
    }
    
}
