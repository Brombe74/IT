
package verifica_andoniu_es2;


public class Rettangolo 
{
    private double base;
    private double altezza;
    private double X;
    private double Y;
    
    public Rettangolo()
    {
        base=1;
        altezza=1;              //costruttore che non prende nulla
        X=0;                    //e istanzia base e altezza a 1 e x,y a 0
        Y=0;
    }
    
    public Rettangolo(double newbase,double newaltezza,double newX,double newY)
    {
        base=newbase;                   //costruttore che istanzia base,altezza e coordinate del vertice in basso a sinistra
        altezza=newaltezza;             //con i parametri ricevuti
        X=newX;                         //x e y sono double in quanto l'utente potrà
        Y=newY;                         //inserire x e y con cifre dopo la virgola    
    }
    
    public double getBase()
    {
        return base;                        //metodi per settare e prendere i vari attributi
    }
    
    public void setBase(double newbase)
    {
        base=newbase;
    }
    
     public double getAltezza()
    {
        return altezza;
    }
    
    public void setAltezza(double newaltezza)
    {
        altezza=newaltezza;
    }
    
    public double getX()
    {
        return X;
    }
    
    public double getY()
    {
        return Y;
    }
    
    public double getArea(double base,double altezza)
    {
        return base*altezza;                                //metodi calcola area e perimetro
    }
    
    public double getPerimetro(double base,double altezza)
    {
        return (base+altezza)*2;
    }
    
}
