
package verifica_andoniu_es2;
import java.util.*;

public class Verifica_Andoniu_es2 {

   
    public static void main(String[] args) 
    {
        Scanner input= new Scanner(System.in);
        Rettangolo ret1 = new Rettangolo(); //dichiaro variabile di tipo Rettangolo 
        double base,altezza,x,y;            //x e y sono double in quanto l'utente potrà
                                            //inserire x e y con cifre dopo la virgola
                                     
        System.out.println("Base (costruttore che non prende niente): "+ret1.getBase());
        System.out.println("Altezza (costruttore che non prende niente): "+ret1.getAltezza());
        System.out.println("X (costruttore che non prende niente): "+ret1.getX());
        System.out.println("Y (costruttore che non prende niente): "+ret1.getY());
        
                                            
        do
        {                                    
             System.out.println("Inserisci la base del Rettangolo:"); //1=1U(unità di misura del rettangolo)
             base=input.nextDouble();
        }
        while(base<=0);    //controllo dovuto al fatto che non esistono misure negative nella realtà
        
        do
        {
             System.out.println("Inserisci l'altezza del Rettangolo:");
             altezza=input.nextDouble(); 
        }
        while(altezza<=0); //controllo dovuto al fatto che non esistono misure negative nella realtà
        
        System.out.println("Inserisci il valore in X del vertice in basso a sinistra del Rettangolo:");
        x=input.nextDouble();
        
        System.out.println("Inserisci il valore in Y del vertice in basso a sinistra del Rettangolo:");
        y=input.nextDouble();
        
        Rettangolo ret2 = new Rettangolo(base,altezza,x,y); //dichiaro variabile di tipo Rettangolo 
        
        System.out.println("Il perimetro di questo Rettangolo: "+ret2.getPerimetro(base, altezza)+"[U]");
        System.out.println("L'are di questo Rettangolo: "+ret2.getArea(base, altezza)+"[U^2]");
        
        do 
        {
             System.out.println("Inserisci la nuova misura della base del Rettangolo:");
             base=input.nextInt();
        }
        while(base<=0);    //controllo dovuto al fatto che non esistono misure negative nella realtà
        
        ret2.setBase(base);
        System.out.println("La tua nuova base: "+ret2.getBase());
        do
        {
             System.out.println("Inserisci la nuova misura dell'altezza del Rettangolo:");
                altezza=input.nextInt();
        }
        while(altezza<=0); //controllo dovuto al fatto che non esistono misure negative nella realtà
        
        ret2.setAltezza(altezza);
        System.out.println("La tua nuova altezza: "+ret2.getAltezza());
       
    }
    
}
