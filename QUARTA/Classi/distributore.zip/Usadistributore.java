
package usadistributore;
import java.util.*;

public class Usadistributore {


    public static void main(String[] args) 
    {  Scanner input=new Scanner(System.in);
       int scelta;
       double litrierogati,prez,spesa;
       double prezzoesso=1.4,prezzoagip=1.42,prezzoconstantin=1.38;
       
       Distributore desso= new Distributore(prezzoesso); 
       Distributore dagip= new Distributore(prezzoagip);
       Distributore dconstantin= new Distributore(prezzoconstantin);
       
       System.out.println("Da quale distributore vuoi prelevare?\n1 per Esso 2 per Agip 3 per Constantin");
       scelta=input.nextInt();
       switch (scelta)
       {
           case 1:
               prez=desso.getprezzo();
               System.out.println("Il prezzo di questo distributore è: "+prez +"E ,quanti litri vuoi erogare?");
               litrierogati=input.nextDouble();
               spesa=desso.Erogadalitri(litrierogati);
               System.out.println("Erogazione riuscita\nSpesa da pagare "+spesa+"E");
               break;
           case 2:
               prez=dagip.getprezzo();
               System.out.println("Il prezzo di questo distributore è: "+prez +"E ,quanti litri vuoi erogare?");
               litrierogati=input.nextDouble();
               spesa=dagip.Erogadalitri(litrierogati);
               System.out.println("Erogazione riuscita\nSpesa da pagare "+spesa+"E");
               break;
           case 3:
               prez=dconstantin.getprezzo();
               System.out.println("Il prezzo di questo distributore è: "+prez +"E ,quanti litri vuoi erogare?");
               litrierogati=input.nextDouble();
               spesa=dconstantin.Erogadalitri(litrierogati);
               System.out.println("Erogazione riuscita\nSpesa da pagare "+spesa+"E");
               break;
       
       default:       
        System.out.println("Non esiste questo distributore");
       }
       
    }
    
}
