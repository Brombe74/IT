
package usadistributore;

public class Distributore {
    //variabili di classe
    private double deposito;
    private double euroPerLitro;
    
    //costruttore
    public Distributore()
    {
        deposito=0;
        euroPerLitro=0;
    }
    public Distributore(double Prezzoperlitro)
    {
        euroPerLitro=Prezzoperlitro;
        deposito=0.;
    }
    //aggiornare deposito
    public void Rifornimento(double litri)
    {
        deposito=deposito+litri;
    }
    public void vendita(double litri)
    {
        deposito=deposito-litri;
    }
    public void setprezzo(int nuovoprezzo)
    {
        euroPerLitro=nuovoprezzo;
    }
    public double getprezzo()
    {
        return euroPerLitro;
    }
    //metodo che eroga carburante e restituisce il prezzo da pagare
    //fare get deposito
    public double Erogadaspesa(double Spesa)
    {  deposito=deposito-Spesa;
       return Spesa*euroPerLitro;
    }
    public double Erogadalitri(double Spesa)
    {  deposito=deposito-Spesa;
       return Spesa*euroPerLitro;
    }
}
