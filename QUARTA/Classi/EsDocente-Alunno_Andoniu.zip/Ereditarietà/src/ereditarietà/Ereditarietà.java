
package ereditarietà;
import java.util.*;

public class Ereditarietà {

    
    public static void main(String[] args) 
    {
      Scanner input= new Scanner(System.in);
      
      
    }
    
}
