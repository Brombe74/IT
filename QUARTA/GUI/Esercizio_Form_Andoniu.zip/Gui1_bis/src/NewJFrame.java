
public class NewJFrame extends javax.swing.JFrame {

   
    public NewJFrame()
    {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_Cambio_nome_bott = new javax.swing.JButton();
        btn_Cambia_Etichetta = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Etichetta2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btn_Cambio_nome_bott.setText("Cambio testo secondo bottone");
        btn_Cambio_nome_bott.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Cambio_nome_bottActionPerformed(evt);
            }
        });

        btn_Cambia_Etichetta.setText("Cambio testo etichetta");
        btn_Cambia_Etichetta.setName("btn_Cambia_Etichetta"); // NOI18N
        btn_Cambia_Etichetta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Cambia_EtichettaActionPerformed(evt);
            }
        });

        jLabel1.setText("Etichetta");

        Etichetta2.setText("Etichetta 2");

        jButton1.setText("Cambia il nome del secondo bottone");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_Cambia_Etichetta)
                            .addComponent(btn_Cambio_nome_bott)
                            .addComponent(jButton1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(131, 131, 131)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Etichetta2)
                            .addComponent(jLabel1))))
                .addContainerGap(72, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(btn_Cambio_nome_bott)
                .addGap(18, 18, 18)
                .addComponent(btn_Cambia_Etichetta, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(Etichetta2)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        Etichetta2.getAccessibleContext().setAccessibleName("Etichetta 2");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_Cambia_EtichettaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Cambia_EtichettaActionPerformed
        jLabel1.setText("Testo cambiato");
    }//GEN-LAST:event_btn_Cambia_EtichettaActionPerformed

    private void btn_Cambio_nome_bottActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Cambio_nome_bottActionPerformed
       btn_Cambia_Etichetta.setText("Cambia il testo dell'etichetta");
    }//GEN-LAST:event_btn_Cambio_nome_bottActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Etichetta2.setText("Cambio Avvenuto");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Etichetta2;
    private javax.swing.JButton btn_Cambia_Etichetta;
    private javax.swing.JButton btn_Cambio_nome_bott;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
