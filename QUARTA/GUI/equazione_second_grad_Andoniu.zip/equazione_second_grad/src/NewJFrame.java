

public class NewJFrame extends javax.swing.JFrame {

    double xsec,x,term,r1,r2;
    
    
    public NewJFrame() {
        initComponents();
        lbl_ris1.setVisible(false);
        lbl_ris2.setVisible(false);
        
    }

    public static double delta(double xsec, double x, double term)
    {
        double delta;
        
        delta=(x*x)-4*(xsec*term);
        
        return delta;
    }
    
    public static double ris1(double xsec, double x, double term)
    {
        double delta=delta(xsec,x,term);
        double ris1=(-x+Math.sqrt(delta))/2*xsec;
        
        return ris1;
    }
    public static double ris2(double xsec, double x, double term)
    {
        double delta=delta(xsec,x,term);
        double ris2=(-x+Math.sqrt(delta))/2*xsec;
        
        return ris2;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_xsec = new javax.swing.JLabel();
        lbl_x = new javax.swing.JLabel();
        lbl_ter = new javax.swing.JLabel();
        txt_xsec = new javax.swing.JTextField();
        txt_x = new javax.swing.JTextField();
        txt_term = new javax.swing.JTextField();
        btn_calc = new javax.swing.JButton();
        lbl_ris = new javax.swing.JLabel();
        lbl_risbis = new javax.swing.JLabel();
        lbl_ris1 = new javax.swing.JLabel();
        lbl_ris2 = new javax.swing.JLabel();
        btn_reset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbl_xsec.setText("x^2");

        lbl_x.setText("x");

        lbl_ter.setText("termine noto");

        txt_xsec.setText("jTextField1");
        txt_xsec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_xsecActionPerformed(evt);
            }
        });

        txt_x.setText("jTextField2");
        txt_x.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_xActionPerformed(evt);
            }
        });

        txt_term.setText("jTextField3");
        txt_term.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_termActionPerformed(evt);
            }
        });

        btn_calc.setText("Calcola risultati");
        btn_calc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_calcActionPerformed(evt);
            }
        });

        lbl_ris.setText("Risultato 1");

        lbl_risbis.setText("Risultato 2");

        lbl_ris1.setText("jLabel6");

        lbl_ris2.setText("jLabel7");

        btn_reset.setText("Reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lbl_xsec)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_xsec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(lbl_x)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_x, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(lbl_ter)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_term, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lbl_ris)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lbl_risbis))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lbl_ris1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lbl_ris2)))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(btn_reset)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(130, Short.MAX_VALUE)
                .addComponent(btn_calc)
                .addGap(125, 125, 125))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_xsec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_xsec))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_x, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_x))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_term, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_ter))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(lbl_ris)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_ris1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_calc)
                        .addGap(35, 35, 35)
                        .addComponent(lbl_risbis)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_ris2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(btn_reset)
                        .addGap(56, 56, 56))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_xsecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_xsecActionPerformed
        xsec=Double.parseDouble(txt_xsec.getText());
    }//GEN-LAST:event_txt_xsecActionPerformed

    private void txt_xActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_xActionPerformed
        x=Double.parseDouble(txt_x.getText());
    }//GEN-LAST:event_txt_xActionPerformed

    private void txt_termActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_termActionPerformed
        term=Double.parseDouble(txt_term.getText());
    }//GEN-LAST:event_txt_termActionPerformed

    private void btn_calcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_calcActionPerformed
        r1=ris1(xsec,x,term);
        r2=ris2(xsec,x,term);
        
        lbl_ris1.setText(Double.toString(r1));
        lbl_ris1.setVisible(true);
        
        lbl_ris2.setText(Double.toString(r2));
        lbl_ris2.setVisible(true);
        
    }//GEN-LAST:event_btn_calcActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
       lbl_ris1.setText(" ");
       lbl_ris1.setVisible(false);
       
       lbl_ris2.setText(" ");
       lbl_ris2.setVisible(false);
       
       txt_xsec.setText(" ");
       txt_x.setText(" ");
       txt_term.setText(" ");
       
    }//GEN-LAST:event_btn_resetActionPerformed

    
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_calc;
    private javax.swing.JButton btn_reset;
    private javax.swing.JLabel lbl_ris;
    private javax.swing.JLabel lbl_ris1;
    private javax.swing.JLabel lbl_ris2;
    private javax.swing.JLabel lbl_risbis;
    private javax.swing.JLabel lbl_ter;
    private javax.swing.JLabel lbl_x;
    private javax.swing.JLabel lbl_xsec;
    private javax.swing.JTextField txt_term;
    private javax.swing.JTextField txt_x;
    private javax.swing.JTextField txt_xsec;
    // End of variables declaration//GEN-END:variables
}
