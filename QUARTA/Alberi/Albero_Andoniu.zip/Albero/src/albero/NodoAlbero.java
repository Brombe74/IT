
package albero;

public class NodoAlbero 
{
    private char info;
    private NodoAlbero dx;
    private NodoAlbero sx;
    
    public NodoAlbero(char c)
    {
        this.info=c;
        sx=null;
        dx=null;
    }
    
    public void setinfo(char c)
    {
        this.info=c;
    }  
    public char getinfo()
    {
        return this.info;
    }
    
    public void setfigliodx(NodoAlbero nuovo)
    {
        this.dx=nuovo;
    }
    public NodoAlbero getfigliodx()
    {
        return this.dx;
    }
    
    public void setfigliosx(NodoAlbero nuovo)
    {
        this.sx=nuovo;
    }
    public NodoAlbero getfigliosx()
    {
        return this.sx;
    }
}
