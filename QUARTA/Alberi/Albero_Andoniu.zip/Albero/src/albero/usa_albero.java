
package albero;

public class usa_albero {

   
    public static void main(String[] args)
    {
        albero a=new albero();
        a.addFiglioDx('A','A');
        a.Stampa_Pre(a.ptr);       //stampe di debug
        System.out.println();
        
        a.addFiglioDx('A','F');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
        a.addFiglioDx('F','H');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
        a.addFiglioSx('A','B');
        a.Stampa_Pre(a.ptr);  
        System.out.println();
        
        a.addFiglioSx('B','C');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
        a.addFiglioSx('C','D');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
       
        
        a.addFiglioDx('D','E');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
        a.addFiglioDx('C','G');
        a.Stampa_Pre(a.ptr);
        System.out.println();
        
        /*
                    A
                   / \
                 B    F  
                /      \
              C         H 
             / 
           D
            \
             E 
        */        
        
        System.out.println("STAMPA PRE-ORDER");
        a.Stampa_Pre(a.ptr);
        System.out.println("\nSTAMPA IN-ORDER");
        a.Stampa_In(a.ptr);
        System.out.println("\nSTAMPA POST-ORDER");
        a.Stampa_Post(a.ptr);
        
    }    
}
