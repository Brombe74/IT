
package somma_albero;

public class Funzioni 
{
    public Nodo ptr;
    
    public Funzioni()
    {
        ptr=null;
    }
    
    public void addFiglioDx(int ricerca,int  figlio)
    {
        Nodo n=new Nodo(figlio);
        if(this.ptr==null) //albero vuoto prima volta sto creando la radice
        {
            this.ptr=n;
            return; //creazione radice e termina 
        }
        
        Nodo p;
   //   p=cerca(ricerca);
        
        if(p!=null)
        {
            p.setfigliodx(n);
        } 
    }
    
    public void addFiglioSx(int cerca,int figlio)
    {
        Nodo n=new Nodo(figlio);
        if(this.ptr==null) //albero vuoto prima volta sto creando la radice
        {
            this.ptr=n;
            return; //creazione radice e termina 
        }
        
        Nodo p;
  // p=cerca(ricerca);
        
        if(p!=null)
        {
            p.setfigliosx(n);
        }      
            
    }


    private boolean cerca(int cerca)
    {
        Nodo temp;
        Nodo padre;
        padre=ptr;
        temp=ptr;
        
        boolean research=false;
        
        while(temp!=null)
        {
            if(temp.getinfo()==cerca)
              {
                  //salvo la radice per entrare nelle foglie
                  padre=ptr;
                  research=false;
              }
            
            if(temp.getfigliosx()!=null)
            {
                temp=temp.getfigliosx();
                
            }
            
        }    
            
        
        return research;
    }
}    