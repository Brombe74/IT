
package somma_albero;


public class Nodo 
{

    private int info;
    private Nodo dx;
    private Nodo sx;
    
    public Nodo(int c)
    {
        this.info=c;
        sx=null;
        dx=null;
    }
    
    public void setinfo(char c)
    {
        this.info=c;
    }  
    public int getinfo()
    {
        return this.info;
    }
    
    public void setfigliodx(Nodo nuovo)
    {
        this.dx=nuovo;
    }
    public Nodo getfigliodx()
    {
        return this.dx;
    }
    
    public void setfigliosx(Nodo nuovo)
    {
        this.sx=nuovo;
    }
    public Nodo getfigliosx()
    {
        return this.sx;
    }


}
