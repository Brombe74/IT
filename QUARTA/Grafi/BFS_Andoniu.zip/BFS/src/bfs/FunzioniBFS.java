
package bfs;
import java.util.*;

public class FunzioniBFS
{
    //definizione costante, grandezza massima della grandezza del grafo
    private final int MAX=100;
    Scanner input=new Scanner(System.in);
    
public ArrayList<Nodo> leggiLista() 
{
  Nodo p=new Nodo();
  Nodo primo=new Nodo();
  ArrayList<Nodo> lista=new ArrayList();
  int x, n, i;
  
  System.out.print("Numero di elementi nella lista: ");
  n=input.nextInt();
  
  for (i=0; i<n; i++) 
  {
    x=input.nextInt();
    
    p.setinfo(x);
    p.setnext(primo);
    lista.add(p);
    primo = p;
  }
  
  return lista;
}

public int leggiGrafo(ArrayList<Nodo> lista[]) {
  int i, n;
  
  System.out.print("Numero di vertici: ");
  n=input.nextInt();
   
  for (i=0; i<n; i++)
  {
    System.out.print("Lista di adiacenza del vertice "+i+"\n");
    lista.add(leggiLista());
  }
  
  return n;
}

void accoda(Nodo primo[],Nodo ultimo[], int x) 
{
  Nodo p=new Nodo();
  p.setinfo(x);
  p.setnext(null);
  
  if (primo == null)
  {
    primo[0]=p;
  }
   
  int i=0;
    
  while (ultimo != null)
  {
    i++;
  }
  
  ultimo[i].setnext(p);
  
  ultimo = p;
  
}

}
