
package bfs;
import java.util.*;


public class BFS 
{

    public static void main(String[] args)
    {
     Scanner input=new Scanner(System.in);
     
     int i;
     int n;
     ArrayList<Integer> d=new ArrayList(); 
     ArrayList<Integer> pi=new ArrayList();
     int sorgente;
     ArrayList<Nodo> lista=new ArrayList();
     
     n = leggiGrafo(lista);
  
     System.out.print("Sorgente della visita: ");
     sorgente=input.nextInt();
  
     bfs(lista, n, d, pi, sorgente);
  
     for (i=0; i<n; i++) 
     {
        System.out.print("Vertice"+i+": padre=%d, distanza=%d\n" pi[i], d[i]);
     }
    }
    
}
