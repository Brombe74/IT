package bfs;

public class Nodo
{
    private int info;
    private Nodo next;
    
    public Nodo()
    {
        this.info=0;
        this.next=null;
    }
    
    //get e set di info
    public int getinfo()
    {
        return this.info;
    }
    public void setinfo(int inf)
    {
        this.info=inf;
    }
    
    //get e set di next
    public Nodo getnext()
    {
        return this.next;
    }
    public void setnext(Nodo n)
    {
        this.next=n;
    }
}
