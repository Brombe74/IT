#include <stdio.h>
#include <stdlib.h>

typedef struct list pila;
struct list 
{						//definizione struct
	pila* next;
	int numero;
};

pila* creanodo(int n);			//prototipi delle funzioni
pila* InserimentoTesta(pila* p,int n);
void Stampa(pila* p);
pila* Push(pila* p,int n);
pila* Pop(pila* p,pila* ris,int n);

int main()
{
	pila* stack;
	stack=NULL;
	pila* temp=stack;
	pila* risult=NULL;
	
	
	int n;	//variabile di inserimento
	
	do
	{
		printf("\nInserisci un valore da mettere nella pila:");
		scanf("%d",&n);
						//ciclo di inserimento 
		if(n>0)
		{
			temp=Push(temp,n);
		}	
		
	}while(n>0);
	
	//Stampa(temp); errore nella funziona di stampa, non sono riuscito a risolvere
	
	do
	{
		printf("\nInserisci il numero di elementi che vuoi copiare:");
		scanf("%d",&n);
		
	}while(n<0);
	
	risult=Pop(temp,risult,n);
	
	printf("\nLa pila dopo il pop");
	
	//Stampa(stack);
	
	return 0;
}

pila* creanodo(int n)	//creazione nuovo nodo
{
	pila* nodo=NULL;	
	
	nodo=(pila*)malloc(sizeof(pila));	//allocazione
	
	if(nodo==NULL)
	{				//gestione errore
		printf("Errore nella creazione del nodo");
		return NULL;
	}
	
	nodo->numero=n;	//assegnazione del valore
	nodo->next=NULL;
	
	return nodo;
}

void Stampa(pila* p)
{					//funzione di stampa
	
	while(p!=NULL);
	{

		if(p->next!=NULL)
		{
			printf("/"); //stampa di separazione
		}
		p=p->next;
	}
}

pila* Push(pila* p1,int n)	//funzione di push
{
	pila* testa=NULL;
	pila* coda=NULL;
	
	testa=p1;	//mi salvo la testa
	
	coda=creanodo(n); //creazione di un nuovo nodo
	
	if(p1==NULL)
	{				//se la lista passata è vuota
					//la coda è la testa
		return coda;
	}
	
	while(p1->next!=NULL)
	{						//scorrimento lista fino al penultimo elemento
		p1=p1->next;
		
	}
	p1->next=coda;		//aggiungo il nodo alla lista	

    return testa;
}

pila* Pop(pila* p,pila* ris,int n)
{
	pila* temp;		//funzione di pop
	temp=ris;
	
	while(temp->next!=NULL && n>0)
	{	
		ris->numero=p->numero;	//scorrimento e copia 
		ris=ris->next;					
		p=p->next;	
		
		n--;
	}
	
	return temp;
}

