#include <stdio.h>
#include <stdlib.h>

typedef struct list pila;
struct list 
{						//definizione struct
	pila* next;
	int numero;
};

pila* creanodo(int n);			//prototipi delle funzioni
pila* InserimentoTesta(pila* p,int n);
void Stampa(pila* p);
pila* Push(pila* p,int n);
pila* Pop(pila* p);

int main()
{
	pila* stack;
	stack=NULL;
	
	int n;	//variabile di inserimento
	
	do
	{
		printf("\nInserisci un valore da mettere nella pila:");
		scanf("%d",&n);
							//ciclo di inserimento 
		if(n>0)
		{
			stack=InserimentoTesta(stack,n);
		}	
		
	}while(n>0);
	
	Stampa(stack);
	
	stack=Pop(stack);
	
	printf("La pila dopo il pop\n");
	
	Stampa(stack);
	
	do
	{
		printf("\nInserisci il numero del push:");
		scanf("%d",&n);
								//ciclo per il push
		if(n>0)
		{
			stack=Push(stack,n);
		}
		
	}while(n<0);
	
	printf("\nLa pila dopo il push");
	
	Stampa(stack);
	
	return 0;
}

pila* InserimentoTesta(pila* p,int n)
{							//funzione di inserimento in testa
	p=(pila*)malloc(sizeof(pila));
	
	p->numero=n;
	p->next=NULL;
	
	return p;
}

void Stampa(pila* p)
{					//funzione di stampa
	
	while(p!=NULL);
	{
		printf("%d",p->numero);

		if(p->next!=NULL)
		{
			printf("/"); //stampa di separazione
		}
		p=p->next;
	}
}

pila* Pop(pila* p)
{
	pila* temp;		//funzione di pop
	temp=p;
	
	p=p->next;
	
	free(temp);
	
	return p;
}

pila* Push(pila* p,int n)
{
	
	
	return p;
}
