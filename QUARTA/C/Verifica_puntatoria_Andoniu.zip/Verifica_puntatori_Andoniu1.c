#include <stdio.h>
#include <stdlib.h>

typedef struct list lista;
struct list 
{						//definizione struct
	lista* next;
	lista* prev;
	int metri;
};

lista* creanodo(int n);			//prototipi delle funzioni
lista* InserimentoCoda(lista* l,int n);
void Stampa(lista* l1);
lista* cancellanodo(int n,lista* l);
lista* ordinalista(lista* l);

int main()
{
	lista* graduatoria=NULL;
	
	int n,pos;	//variabili per inserimento e nodo da cancellare
	
	do
	{
		printf("\nInserisci l'ampiezza del salto: ");
		scanf("%d",&n);
		
		if(n>0)
		{
		 	graduatoria=InserimentoCoda(graduatoria,n);
		}
		
	}while(n>0);
	
	Stampa(graduatoria);
	
	do
	{
		printf("\nInserisci il nodo che vuoi cancellare:");
		scanf("%d",&pos);		//ciclo per verificare l'esistenza del nodo richiesto
		
	}while(pos<1);
	
	graduatoria=cancellanodo(pos,graduatoria);
	
	printf("\n");	//stampa di divisione
	
	Stampa(graduatoria);

	
	return 0;
}

lista* creanodo(int n)	//creazione nuovo nodo
{
	lista* nodo=NULL;	
	
	nodo=(lista*)malloc(sizeof(lista));	//allocazione
	
	if(nodo==NULL)
	{				//gestione errore
		printf("Errore nella creazione del nodo");
		return NULL;
	}
	
	nodo->metri=n;	//assegnazione del valore
	nodo->next=NULL;
	
	return nodo;
}

lista* InserimentoCoda(lista* l1,int n)
{
	lista* testa=NULL;
	lista* coda=NULL;
	
	testa=l1;	//mi salvo la testa
	
	coda=creanodo(n); //creazione di un nuovo nodo
	
	if(l1==NULL)
	{				//se la lista passata è vuota
					//la coda è la testa
		return coda;
	}
	
	while(l1->next!=NULL)
	{				
		l1->next->prev=l1;		//scorrimento lista fino al penultimo elemento
		l1=l1->next;
		
	}
	l1->next=coda;		//aggiungo il nodo alla lista	
    
    
    return testa;
}

void Stampa(lista* l1)
{							//funzione di stampa
	if(l1==NULL)
	{
		printf("\nLISTA VUOTA");
		return;
	}						
	
	while(l1!=NULL)
	{
		printf("%d",l1->metri);
		
		if(l1->next!=NULL)
		{
			printf("/"); //stampa di separazione
		}
		l1=l1->next;
	}
	
}

lista* cancellanodo(int n,lista* l)
{
	int c=0;		//variabile per lo scorrimento
	lista* temp;	//variabile temporanea 
	
	
	while(c!=n-1)
	{	
		l=l->next;
		c++;
	}
	
	if(c==n-1)
	{	
		temp=l;
		l=l->next;
		temp->next->prev=temp->prev;
		temp->prev->prev=temp->next;
		free(temp);	
	}
	
	else if(l->next==NULL)
	{				//gestione caso di fine lista
		temp=l;
		l->next=NULL;
		free(temp);
	}
	
	
	return l;
}
