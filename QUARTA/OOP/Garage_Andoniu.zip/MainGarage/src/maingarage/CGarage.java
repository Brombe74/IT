
package maingarage;
import java.util.*;
public class CGarage 
{
    Scanner input=new Scanner(System.in);
    
    private CVeicoloAMotore veicoli;
    
    
}
