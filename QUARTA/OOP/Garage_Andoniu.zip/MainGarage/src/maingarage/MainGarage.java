
package maingarage;


public class MainGarage {

    
    public static void main(String[] args) 
    {
        
    }
    
}
