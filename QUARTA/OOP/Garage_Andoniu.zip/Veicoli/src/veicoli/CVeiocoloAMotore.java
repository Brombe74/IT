
package veicoli;
import java.util.*;

public class CVeiocoloAMotore
{
    protected int annoImmatricolazione;
    protected String Marca;
    protected String tipoAlimentazione;
    protected int cilindrata;
    
 public int getAnnoImm()
{
  return this.annoImmatricolazione; 
}

}
 

