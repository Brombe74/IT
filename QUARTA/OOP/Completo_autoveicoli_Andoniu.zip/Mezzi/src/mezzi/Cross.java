
package mezzi;
import java.util.*;


/**
 * Class Cross
 */
public class Cross extends Motocicli {

 static private Scanner input= new Scanner(System.in);
  /**
   * MXGP-MX2
   */
  private String Categoria;
  
  //
  // Constructors
  //
  public Cross () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of Categoria
   * MXGP-MX2
   * @param newVar the new value of Categoria
   */
  private void setCategoria (String newVar) {
    Categoria = newVar;
  }

  /**
   * Get the value of Categoria
   * MXGP-MX2
   * @return the value of Categoria
   */
  private String getCategoria () {
    return Categoria;
  }

  //
  // Other methods
  //

}
