
package mezzi;
import java.util.*;



abstract public class Motocicli extends Veicolo {

  static private Scanner input= new Scanner(System.in);
  
  private boolean cavaletto;
  private boolean pedali;
  private int cilindrata;
  private String tipo_gomme;
  
  //
  // Constructors
  //
  public Motocicli () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of cavaletto
   * @param newVar the new value of cavaletto
   */
  private void setCavaletto (boolean newVar) {
    cavaletto = newVar;
  }

  /**
   * Get the value of cavaletto
   * @return the value of cavaletto
   */
  private boolean getCavaletto () {
    return cavaletto;
  }

  /**
   * Set the value of pedali
   * @param newVar the new value of pedali
   */
  private void setPedali (boolean newVar) {
    pedali = newVar;
  }

  /**
   * Get the value of pedali
   * @return the value of pedali
   */
  private boolean getPedali () {
    return pedali;
  }

  /**
   * Set the value of cilindrata
   * @param newVar the new value of cilindrata
   */
  private void setCilindrata (int newVar) {
    cilindrata = newVar;
  }

  /**
   * Get the value of cilindrata
   * @return the value of cilindrata
   */
  private int getCilindrata () {
    return cilindrata;
  }

  /**
   * Set the value of tipo_gomme
   * @param newVar the new value of tipo_gomme
   */
  private void setTipo_gomme (String newVar) {
    tipo_gomme = newVar;
  }

  /**
   * Get the value of tipo_gomme
   * @return the value of tipo_gomme
   */
  private String getTipo_gomme () {
    return tipo_gomme;
  }

  //
  // Other methods
  //

  /**
   * @return       boolean
   * @param        cavaletto
   */
  public boolean tira_cavaletto(boolean cavaletto)
  {
      return true;
  }


}
