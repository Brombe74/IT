
package mezzi;
import java.util.*;



public class SUV extends AutoVeicoli {

  static private Scanner input= new Scanner(System.in);

  private char Trazione;
  
 
  public SUV () { };
  


  private void setTrazione (char newVar) 
  {
    Trazione = newVar;
  }

  private char Controllo_trazione(char trazione)
  {
 char scelta;
      
      System.out.println("Inserisci il tipo di trazione"
              +"\n[a] per anteriore [p] per posteriore [i] per integrale");
      scelta=input.nextLine().charAt(0);
      
      if(scelta==trazione)
      {
          System.out.println("Hai già questo tipo di trazione");
      }
      else
      {
        switch(scelta)
        {
              case 'a':
                 setTrazione(scelta);
                  break;
                  
              case 'p':
                  setTrazione(scelta);
                  break;
                  
              case 'i':
                  setTrazione(scelta);
                  break;
                  
              default:
                  System.out.println("Trazione non disponibile");
                      
        }
      }
  }
  private char getTrazione () 
  {
    return Trazione;
  }

  //
  // Other methods
  //

  /**
   * @return       String
   * @param        trazione
   */
  public String Cambia_trazione(String trazione)
  {
      return "S";
  }


}

