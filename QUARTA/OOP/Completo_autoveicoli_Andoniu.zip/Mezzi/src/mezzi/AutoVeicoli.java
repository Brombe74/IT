
package mezzi;
import java.util.*;


abstract public class AutoVeicoli extends Veicolo {
    
  static private Scanner input= new Scanner(System.in);
  
  private boolean Airbag;
  private int Posti=0;
  private char tipo_gomme='d';
  private int n_porte=0;
  
  public AutoVeicoli ()
  {
      
  }

  protected void setAirbag (boolean airbag) 
  {
    this.Airbag = airbag;
  }

  
  protected boolean getAirbag () 
  {
    return this.Airbag;
  }

  private int controllo_posti(int posti)
  {
      int n_posti=posti;
      
      while(n_posti<1)
      {
       System.out.println("Inserisci il numero di posti");
       n_posti=input.nextInt();
      }
      return n_posti;
  }
  protected void setPosti (int posti) 
  {
    this.Posti = controllo_posti(posti);
  }

  
  protected int getPosti () 
  {
    return this.Posti;
  }

private char controllo_gomme(char gomme)
{
    char n_gomme=gomme;
    
   while(n_gomme != 'i' || n_gomme != 'e' ||n_gomme != 'l' ||n_gomme != 'u')
   {
       System.out.println("Inserisci il tipo di gomme\n"
               + "[i] per invernali [e] per estive [l] per lisce [u] universali");
       n_gomme=input.nextLine().charAt(0);
   }
   
   return n_gomme;
}
  protected void setTipo_gomme (char gomme ) 
  {
    this.tipo_gomme = controllo_gomme(gomme);
  }


  protected char getTipo_gomme () 
  {
    return tipo_gomme;
  }

  private int controllo_porte(int porte)
  {
      while(porte<2)
      {
          System.out.println("Inserisci quante porte ha la macchina");
          porte=input.nextInt();
      }
      return porte;
  }
  protected void setN_porte (int n_porte) 
  {
    this.n_porte = controllo_porte(n_porte);
  }

  protected int getN_porte () {
    return n_porte;
  }

  public void cambio_gomme(char tipo_gomme)
  {
      char scelta;
      
      System.out.println("Inserisci il nuovo tipo di gomme"
              +"\n[i] per invernali [e] per estive [l] per lisce [u] universali");
      scelta=input.nextLine().charAt(0);
      
      if(scelta==tipo_gomme)
      {
          System.out.println("Hai già questo tipo di gomme");
      }
      else
      {
        switch(scelta)
        {
              case 'i':
                 setTipo_gomme(scelta);
                  break;
                  
              case 'e':
                  setTipo_gomme(scelta);
                  break;
                  
              case 'l':
                  setTipo_gomme(scelta);
                  break;
                  
              case 'u':
                  setTipo_gomme(scelta);
                  break;
              default:
                  System.out.println("Gomme non disponibili");
                      
        }
      }
  }


}
