
package mezzi;
import java.util.*;


  final public class Utilitaria extends AutoVeicoli
  {
  Scanner input= new Scanner(System.in);
  
  private int Grand_baga=0;
  
 
  public Utilitaria () { };
  
 private int controllo_baga(int grand)
 {
     while(grand<50)
     {
         System.out.println("Inserisci la grandezza del bagagliaio");
         grand=input.nextInt();
     }
     
     return grand;
 }
  
  protected void setGrand_baga (int n_grand) 
  {
    this.Grand_baga = controllo_baga(n_grand);
  }

  
  protected int getGrand_baga () 
  {
    return this.Grand_baga;
  }


  public int Carica_bagagli()
  {
      int carico;
      System.out.println("Inserisci di quanto vuoi caricare il bagagliaio");
      carico=input.nextInt();
      while(carico>this.Grand_baga || carico<0)
      {
          System.out.println("Reinserisci il carico");
          carico=input.nextInt();
      }
      
      System.out.println("Bagagliaio caricato");
      return 0;
  }


}
