
package mezzi;
import java.util.*;


abstract public class Veicolo {

  static private Scanner input= new Scanner(System.in);

  private int N_ruote=4;
  private char Colore='p';
  private char Tipo_di_carburante;
  private int grand_serbatoio;
  
  public Veicolo ()
  { 
  }

   private int controllo_ruote(int n_ruote)
  {
      while(n_ruote != 4 || n_ruote != 2)
      {
          System.out.println("Inserisci quante ruote ha il veicolo");
          n_ruote=input.nextInt();
      }
      return n_ruote;
  }
  protected void setN_ruote(int n_ruote)
  {
      this.N_ruote=controllo_ruote(n_ruote);
  }        
  
  protected int getN_ruote () {
    return this.N_ruote;
  }

  private char controllo_colore(char n_colore)
  {
      while(n_colore !='n'|| n_colore !='b' || n_colore !='a' || n_colore !='r')
      {
          System.out.println("Inserisci il colore del Veicolo\n"
                  + "[n] per nero [b] per bianco [a] per arancione [r] per rosso");
          n_colore=input.nextLine().charAt(0);
      }
      return n_colore;
  }
  
  protected void setColore (char n_colore) 
  {
    this.Colore=controllo_colore(n_colore);
  }

  protected int getColore ()
  {
    return this.Colore;
  }

 private char controllo_tipo_carburante(char n_tipo__carburante)
 {
     while(n_tipo__carburante !='b'|| n_tipo__carburante !='g')
      {
          System.out.println("Inserisci il tipo di carburante del Veicolo\n"
                  + "[b] per benzina [g] per gasolio");
          n_tipo__carburante=input.nextLine().charAt(0);
      }
      return n_tipo__carburante;
 }
 
  protected void setTipo_di_carburante (char n_tipo_carburante) 
  {
    this.Tipo_di_carburante = controllo_tipo_carburante(n_tipo_carburante);
  }

  protected char getTipo_di_carburante () 
  {
    return Tipo_di_carburante;
  }

  private int controllo_grand_serbatoio(int n_grand_serb)
  {
      while(n_grand_serb<45)
      {
          System.out.println("Inserisci la grandezza del serbatoio");
          n_grand_serb=input.nextInt();
      }
      return n_grand_serb;
  }        
  
  protected void setGrand_serbatoio (int grand_serb) 
  {
    this.grand_serbatoio = controllo_grand_serbatoio(grand_serb);
  }

  private int getGrand_serbatoio () 
  {
    return this.grand_serbatoio;
  }

  public void Fai_rifornimento()
  {
     int rifornimento;
     
     System.out.println("Inserisci quanti litri di carburante vuoi mettere");
     rifornimento=input.nextInt();
     
     if(rifornimento>this.grand_serbatoio)
     {
         System.out.println("NE STAI METTENDO TROPPO");
     }
     else
         System.out.println("Rifornimento andato a buon fine");
  }


}

