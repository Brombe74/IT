
package mezzi;

/**
 *
 * @author s01525
 */
public class Mezzi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
