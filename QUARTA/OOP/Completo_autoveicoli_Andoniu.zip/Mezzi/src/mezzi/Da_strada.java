
package mezzi;
import java.util.*;


/**
 * Class Da_strada
 */
public class Da_strada extends Motocicli {

  static private Scanner input= new Scanner(System.in);
  
  private boolean Cartenatura;
  private boolean luci;
  
  //
  // Constructors
  //
  public Da_strada () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of Cartenatura
   * @param newVar the new value of Cartenatura
   */
  private void setCartenatura (boolean newVar) {
    Cartenatura = newVar;
  }

  /**
   * Get the value of Cartenatura
   * @return the value of Cartenatura
   */
  private boolean getCartenatura () {
    return Cartenatura;
  }

  /**
   * Set the value of luci
   * @param newVar the new value of luci
   */
  private void setLuci (boolean newVar) {
    luci = newVar;
  }

  /**
   * Get the value of luci
   * @return the value of luci
   */
  private boolean getLuci () {
    return luci;
  }

  //
  // Other methods
  //

  /**
   * @return       boolean
   * @param        luci
   */
  public boolean cambia_luci(boolean luci)
  {
      return true;
  }


}
