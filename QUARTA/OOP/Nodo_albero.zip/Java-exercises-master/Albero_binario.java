/*
costruire albero di ricerca binario con funzione di aggiungi Figlio iterattivo  (in Java) ,
fare le visite inorder, pre order e post order, aggiungere le funzioni per ricerca del Max e del MIN
*/

package albero_binario;


public class Albero_binario {

    
    public static void main(String[] args) 
    {
      
      Albero bin=new Albero();  
      
      bin.addnodo(20);
      bin.addnodo(10);
      bin.addnodo(12);
      bin.addnodo(22);
      bin.addnodo(15);
      bin.addnodo(23);
      
      bin.Stampa_Pre(bin.getptr());
      System.out.println();
      bin.Stampa_In(bin.getptr());
      
      System.out.println();
      System.out.println("Valore massimo:"+bin.Massimo());  //test delle funzioni
                                                                            
      System.out.println("Valore minimo:"+bin.Minimo());
      
      System.out.println("La chiave sta al livello:"+bin.livello(10));
      
      System.out.println(bin.ricerca(804));
    }
    
}
