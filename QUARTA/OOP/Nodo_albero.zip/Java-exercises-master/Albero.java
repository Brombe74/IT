//funzioni per l'albero binario

package albero_binario;

public class Albero 
{
    public NodoAlbero ptr;
    
    public Albero()
    {
        ptr=null;
    }
    
    public void addnodo(int key)
    {
        NodoAlbero corrente=null;
        NodoAlbero precedente=null;
        NodoAlbero N=new NodoAlbero(key);
        
        if(ptr==null)
        {               //inserimento radice                                        
            ptr=N;
        }
        else
        {
            corrente=ptr;

            while(corrente!=null)
            {
                precedente = corrente;
                
                if(corrente.getinfo() > key)
                {
                    corrente=corrente.getfigliosx();    
                }
                else
                {
                    corrente=corrente.getfigliodx();
                }
            }
            
            if(precedente.getinfo() > key)
            {
                precedente.setfigliosx(N);
            }
            else
            {
                precedente.setfigliodx(N);
            }
        }
    }
    
    public int Massimo()
    {
        int max;
        NodoAlbero temp=null;
        temp=ptr;
        
        if(ptr==null)
        {
            return 0;
        }
        
        while(temp.getfigliodx()!=null)
        {                               //continuo fino a quando finisco i figli destri
            temp=temp.getfigliodx();
        }
        
        max=temp.getinfo();
        
        return max;
    } 
    
    public int Minimo()
    {
        int min;
        NodoAlbero temp=null;
        temp=ptr;
        
        if(ptr==null)
        {
            return 0;
        }
        
        while(temp.getfigliosx()!=null)
        {                               //continuo fino a quando finisco i figli destri
            temp=temp.getfigliosx();
        }
        
        min=temp.getinfo();
        
        return min;
    }
    
    public int livello(int key)
    {
        int lv=1;
        NodoAlbero temp=null;
        temp=ptr;
        
        if(ptr==null)
        {
            return 0;
        }
        
        while(temp!=null)
        {
            if(temp.getinfo()==key)
            {
                break;   
            }
            if(temp.getinfo()>key)
            {
                temp=temp.getfigliosx();
                lv++;
            }
            else
            {
                temp=temp.getfigliodx();
                lv++;
            }
        }
        return lv;
    }
    
    
    public boolean ricerca(int key)
    {
        NodoAlbero temp=null;
        temp=ptr;
        
        if(ptr==null)
        {
            return false;
        }
        
        while(temp!=null)
        {
            if(temp.getinfo()==key)
            {
                return true;
                
            }
            if(temp.getinfo()>key)
            {
                temp=temp.getfigliosx();
            }
            else
            {
                temp=temp.getfigliodx();
            }
        }
        
        return false;
    }
    
    public void Stampa_Pre(NodoAlbero p)
    {
        if(p==null)
        {
            return;
        }
        
        System.out.print(p.getinfo()+"/");
        
        if(p.getfigliosx()!=null)
        {
            Stampa_Pre(p.getfigliosx());
        }
        
         if(p.getfigliodx()!=null)
        {
            Stampa_Pre(p.getfigliodx());
        }        
    }
    
    public void Stampa_In(NodoAlbero p)
    {
        if(p==null)
        {
            return;
        }    
        if(p.getfigliosx()!=null)
        {
            Stampa_In(p.getfigliosx());
        }
        
        System.out.print(p.getinfo()+"/");
        
         if(p.getfigliodx()!=null)
        {
            Stampa_In(p.getfigliodx());
        }        
    }
    
    public void Stampa_Post(NodoAlbero p)
    {
        if(p==null)
        {
            return;
        }
        
        if(p.getfigliosx()!=null)
        {
            Stampa_Post(p.getfigliosx());
        }
        
         if(p.getfigliodx()!=null)
        {
            Stampa_Post(p.getfigliodx());
        }        
        
        System.out.print(p.getinfo()+"/"); 
    } 
    
    public NodoAlbero getptr()
    {
        return this.ptr;
    }
    
}
