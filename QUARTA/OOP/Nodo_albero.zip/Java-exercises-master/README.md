# Java-exercises
School exercises
