
package animale;

public class Mammifero extends Animale 
{
    
}
