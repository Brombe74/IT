
package animale;

public class Rettile extends Animale
{
    
}
