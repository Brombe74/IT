
package animale;
import java.util.*;


public class MainAnimale {


    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        char scelta;
        
        System.out.println("Inserisci l'animale da descrivere\n"
                + "[M] per mammifero [R] per rettile");
        scelta=input.nextLine().charAt(0);
        
        switch (scelta)
        {
            
        }    
        
        
    }
    
}
