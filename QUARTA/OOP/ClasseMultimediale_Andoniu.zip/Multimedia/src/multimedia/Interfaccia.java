
package multimedia;


 interface Interfaccia
{
    public int darker();
    public int brighter();
    public String Show();
    public int weaker();
    public int louder();
    public String show();
    public String play();
}
